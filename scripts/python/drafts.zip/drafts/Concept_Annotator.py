#####################################################################################################################
# Concept_Annotator.py
# Purpose: script annotates clinical concepts to ontology terms using the NCBO BioPortal API and ontology DbXrefs
# version 1.1.0
# date: 09.05.2018
#####################################################################################################################


# import module/script dependencies
import argparse
from progressbar import ProgressBar, FormatLabel, Percentage, Bar
import os
import pandas as pd
import urllib2
import json
from rdflib import Graph
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from nltk.corpus import stopwords
from nltk.tokenize import RegexpTokenizer
# nltk.download("wordnet")
from nltk.stem import WordNetLemmatizer
from scripts.UMLS_API import *



def authenticate(input_file):
    '''
    Function takes a string containing a file path to a file containing authentication information and returns a list
    where list[0] is an API Key.
    :param input_file: a string containing a file path to a file containing authentication information
    :return: a list where list[0] is API Key
    '''

    # CHECK - file has data
    if os.stat(input_file).st_size == 0:
        return 'ERROR: input file: {} is empty'.format(input_file)

    else:
        # get authentication information
        return open(input_file).read().split('\n')


def get_json(url, key):
    '''
    Function takes a url string and a string containing an API key. The function queries the url using the API Key and
    returns an opener containing results as a json file.
    :param url: string containing a url
    :param key: string containing an API key
    :return: an opener containing results formatted as a json file
    '''

    # set-up endpoint proxy
    proxy = urllib2.ProxyHandler()
    opener = urllib2.build_opener(proxy)
    opener.addheaders = [('Authorization', 'apikey token=' + key)]
    return json.loads(opener.open(url).read())


def result_searcher(REST_URL, search_query, term, API_KEY):
    """
    Function takes a strings which are needed to search for a term using the BioPortal ontology API. The function
    uses this information to query the API and returns a string containing the result of querying the API.
    :param REST_URL: string which contains the API url
    :param search_query: string storing the API search query
    :param term: string storing a term to search against the API
    :param API_KEY: string which contains the API key
    :return: string containing the result of querying the API
    """

    # query the API
    res = get_json(str(REST_URL + str(search_query) + urllib2.quote(term)), API_KEY)

    # process results
    if isinstance(res["collection"], (list,)) and len(res["collection"]) > 0:
        for i in res["collection"]:
            # ensure we are only keeping the correct matches
            if term == str(i['prefLabel'].lower()):
                return i['@id'], str(i['prefLabel'].lower())

            elif 'synonym' in i.keys():
                if len(filter(lambda x: term in x.lower(), i['synonym'] + [str(i['prefLabel'].lower())])) > 0:
                    return i['@id'], str(i['prefLabel'].lower())
                else:
                    return "NONE", "NONE"
            else:
                return "NONE", "NONE"
            break
    else:
        return "NONE", "NONE"

#
# def DbXref_finder(graph, dbxref_type):
#     """
#     Function takes an rdf graph and a string specifying the DbXref as inputs and uses the information to return all
#     ontology concepts and labels matching the DbXref type. The ontology returns a list of lists where each inner list
#     contains an DbXref id, ontology id, and ontology label.
#     :param graph: an rdf graph
#     :param dbxref_type: string specifying the DbXref
#     :return: a list of lists where each inner list contains an DbXref id, ontology id, and ontology label
#     """
#     # query graph to get all cross-referenced sources
#     results = graph.query(
#         """SELECT DISTINCT ?source ?c ?c_label
#            WHERE {
#               ?c rdf:type owl:Class .
#               ?c oboInOwl:hasDbXref ?source .
#               ?c rdfs:label ?c_label .}
#            """, initNs={"rdf": 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
#                         "rdfs": 'http://www.w3.org/2000/01/rdf-schema#',
#                         "owl": 'http://www.w3.org/2002/07/owl#',
#                         "oboInOwl": 'http://www.geneontology.org/formats/oboInOwl#'})
#
#     return [(str(x[0]).split(":")[-1], str(x[1]), str(x[2])) for x in results if dbxref_type in str(x[0])]


def preprocessor(data, var_col, defn_col, dict_syn, dic):
    """
    Using the input two lists, the function assembles an identifier and definition for each question. The definition
    is then preprocessed by making all words lowercase, removing all punctuation, tokenizing by word,
    removing english stop words, and lemmatization (via wordnet). The function returns a list of lists,
    where the first item in each list is the identifier and the second item is a list containing the processed
    question definition.

    :param data: pandas data frame containing variable information
    :param var_col: list of columns used to assemble question identifier
    :param defn_col: list of columns used to assemble question definition
    :return: a list of lists, where the first item in each list is the identifier and the second item is a list
    containing the processed question definition
    """

    widgets = [Percentage(), Bar(), FormatLabel("(elapsed: %(elapsed)s)")]
    pbar = ProgressBar(widgets=widgets, maxval=len(data))

    vocab_dict = []

    for index, row in pbar(data.iterrows()):
        var = str(row[str(var_col[0])]) + "|" + str(row[str(var_col[1])])
        defn = re.sub(r"\s{1,}", " ", str(row[str(defn_col)].encode('ascii', 'ignore')))

        if "|" in defn:
            for i in defn.split(" | "):
                # lowercase
                defn_lower = i.lower()

                # tokenize & remove punctuation
                tok_punc_defn = RegexpTokenizer(r"\w+").tokenize(defn_lower)

                # remove stop words & perform lemmatization
                defn_lemma = [str(WordNetLemmatizer().lemmatize(x)) for x in tok_punc_defn if
                              x not in stopwords.words("english")]

                vocab_dict.append((var, defn_lemma))
        else:
            # lowercase
            defn_lower = defn.lower()

            # tokenize & remove punctuation
            tok_punc_defn = RegexpTokenizer(r"\w+").tokenize(defn_lower)

            # remove stop words & perform lemmatization
            defn_lemma = [str(WordNetLemmatizer().lemmatize(x)) for x in tok_punc_defn if
                          x not in stopwords.words("english")]

            vocab_dict.append((var, defn_lemma))

    # process synonymn dict
    for key, val in dict_syn.items():

        if len(val) > 2:
            for i in val[1::2]:
                var = "|".join([dic[i][0], key, i])
                defn_lower = "|".join([key, i, dic[i][1].encode("ascii", "ignore")])

                # tokenize & remove punctuation
                tok_punc_defn = RegexpTokenizer(r"\w+").tokenize(defn_lower)

                # remove stop words & perform lemmatization
                defn_lemma = [str(WordNetLemmatizer().lemmatize(x)) for x in tok_punc_defn if
                              x not in stopwords.words("english")]

                vocab_dict.append((var, defn_lemma))

        else:
            var = "|".join([val[0], key, dic[val[1]][1]])

            # lowercase
            defn_lower = "|".join([key, val[1], dic[val[1]][1].encode("ascii", "ignore")])

            # tokenize & remove punctuation
            tok_punc_defn = RegexpTokenizer(r"\w+").tokenize(defn_lower)

            # remove stop words & perform lemmatization
            defn_lemma = [str(WordNetLemmatizer().lemmatize(x)) for x in tok_punc_defn if
                          x not in stopwords.words("english")]

            vocab_dict.append((var, defn_lemma))

    pbar.finish()
    return vocab_dict


def similarity_search(tfidf_matrix, index_var, top_n):
    """
    The function calculates the cosine similarity between the index variables and all other included variables in the
    matrix. The results are sorted and returned as a list of lists, where each list contains a variable identifier
    and the cosine similarity score for the top set of similar variables as indicated by the input argument are
    returned.

    :param tfidf_matrix: where each row represents a variables and each column represents a concept and counts are
    weighted by TF-IDF
    :param index_var: an integer representing a variable id
    :param top_n: an integer representing the number of similar variables to return
    :return: a list of lists where each list contains a variable identifier and the cosine similarity
        score the top set of similar as indicated by the input argument are returned
    """

    # calculate similarity
    cosine_similarities = linear_kernel(tfidf_matrix[index_var:index_var + 1], tfidf_matrix).flatten()
    rel_var_indices = [i for i in cosine_similarities.argsort()[::-1] if i != index_var]
    similar_variables = [(variable, cosine_similarities[variable]) for variable in rel_var_indices][0:top_n]

    return similar_variables


def score_variables(var_col, defn_col, label, data, corpus, tfidf_matrix, top_n):
    """
    The function iterates over the corpus and returns the top_n (as specified by user) most similar variables,
    with a score, for each variable as a pandas data frame.

    :param var_col: list of columns used to assemble question identifier
    :param data: pandas data frame containing variable information
    :param corpus: a list of lists, where the first item in each list is the identifier and the second item is a list
    containing the processed question definition
    :param tfidf_matrix: matrix where each row represents a variables and each column represents a concept and counts
    are weighted by TF-IDF
    :param top_n: number of results to return for each variable
    :return: pandas data frame of the top_n (as specified by user) results for each variable
    """
    widgets = [Percentage(), Bar(), FormatLabel("(elapsed: %(elapsed)s)")]
    pbar = ProgressBar(widgets=widgets, maxval=len(data))
    sim_res = []
    matches = 0

    # matching data in filtered file
    for index, row in pbar(data.iterrows()):
        var = str(row[str(var_col[0])]) + "|" + str(row[str(var_col[1])])

        # get index of filter data in corpus
        if "|" in row[defn_col]:
            var_idx = [x for x, y in enumerate(corpus) if y[0] == var]
            if var_idx:
                for v in var_idx:
                    matches += 1
                    omop = corpus[v][0].split(str("|"))[0]
                    sme = "|".join(corpus[v][0].split(str("|"))[1:])

                    # retrieve top_n similar variables
                    for idx, score in similarity_search(tfidf_matrix, v, top_n):
                        if 'http' in corpus[idx][0] and score > 0:
                            sim_res.append([omop, sme, row[label[0]],
                                            corpus[idx][0].split("|")[0],
                                            corpus[idx][0].split("|")[1], score])
                            break
        else:
            var_idx = [x for x, y in enumerate(corpus) if y[0] == var]
            if var_idx:
                matches += 1
                omop = corpus[var_idx[0]][0].split(str("|"))[0]
                sme = corpus[var_idx[0]][0].split(str("|"))[1]

                # retrieve top_n similar variables
                for idx, score in similarity_search(tfidf_matrix, var_idx[0], top_n):
                    if 'http' in corpus[idx][0] and score > 0:
                        sim_res.append([omop, sme, row[label[0]],
                                        corpus[idx][0].split("|")[0],
                                        corpus[idx][0].split("|")[1], score])
                        break

    pbar.finish()

    # create pandas dataframe
    scored_vars = pd.DataFrame(dict(OMOP_ID=[x[0] for x in sim_res],
                                    SNOMED_ID=[x[1] for x in sim_res],
                                    LABEL=[str(x[2].encode('ascii', 'ignore')) for x in sim_res],
                                    ONT_ID=[x[3] for x in sim_res],
                                    ONT_LABEL=[str(x[4].encode('ascii', 'ignore')) for x in sim_res],
                                    score=[x[5] for x in sim_res]))

    return scored_vars


def OntDict(graph):
    # run query to find all database references
    print("Running Query to Identify all Ontology Classes \n")

    results = graph.query(
        """SELECT DISTINCT ?c ?c_label ?defn
           WHERE {
              ?c rdf:type owl:Class .
              ?c rdfs:label ?c_label .
              optional {?c obo:IAO_0000115 ?defn}
              minus {?c owl:deprecated true}
              }
           """, initNs={"rdf": 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
                        "rdfs": 'http://www.w3.org/2000/01/rdf-schema#',
                        "owl": 'http://www.w3.org/2002/07/owl#',
                        "oboInOwl": 'http://www.geneontology.org/formats/oboInOwl#',
                        "obo": 'http://purl.obolibrary.org/obo/'})

    # create progress bar
    widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
    pbar = ProgressBar(widgets=widgets, maxval=len(results))

    # create variable to store results
    res = {}

    print("Processing Query Results \n")

    for row in pbar(results):
        if row[2] != None:
            res[str(row[1].decode('ascii', 'ignore')).lower()] = [str(row[0]),
                                                                  str(row[2].encode('ascii', 'ignore')).lower()]
        else:
            res[str(row[1].decode('ascii', 'ignore')).lower()] = [str(row[0]), ""]

    # close progress bar
    pbar.finish()

    # verify we have results
    if not len(res) > 1:
        raise ValueError('Error - did not return any classes for graph: {0}'.format(len(res)))
    else:
        return res


def DbXRef(graph):
    # create variable to store results
    xref = {}

    # run query to find all database references
    print("Running Query to Identify all DbXRefs \n")
    results = graph.query(
        """SELECT DISTINCT ?dbref ?c ?c_label 
           WHERE {
              ?c rdf:type owl:Class .
              ?c oboInOwl:hasDbXref ?dbref .
              ?c rdfs:label ?c_label .
              minus {?c owl:deprecated true}
              }
           """, initNs={"rdf": 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
                        "rdfs": 'http://www.w3.org/2000/01/rdf-schema#',
                        "owl": 'http://www.w3.org/2002/07/owl#',
                        "oboInOwl": 'http://www.geneontology.org/formats/oboInOwl#'})

    # create progress bar
    widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
    pbar = ProgressBar(widgets=widgets, maxval=len(results))

    print("Processing Query Results \n")

    for row in pbar(results):

        # create dictionary of DbXRefs
        if "SNOMED" in str(row[0]):
            key = "SNOMED:" + str(str(row[0]).split(":")[-1])

            if key in xref.keys():
                xref[key] += [str(row[1]), str(row[2])]
            else:
                xref[key] = [str(row[1]), str(row[2])]
        if "UMLS" in str(row[0]):
            key = str(row[0]).split(":")[-1]
            if key in xref.keys():
                xref[key] += [str(row[1]), str(row[2])]
            else:
                xref[key] = [str(row[1]), str(row[2])]


    # close progress bar
    pbar.finish()

    # verify we have results
    if not len(xref) > 1:
        raise ValueError('Error - did not return any DbXRefs for graph: {0}'.format(len(xref)))
    else:
        return xref


def Synonym(graph):
    # create variable to store results
    syn = {}

    # run query to find all database references
    print("Running Query to Identify all synonyms \n")

    results = graph.query(
        """SELECT DISTINCT ?syn ?c ?c_label ?p
           WHERE {
              ?c rdf:type owl:Class .
              ?c ?p ?syn .
              ?c rdfs:label ?c_label .

              FILTER(?p in (oboInOwl:hasExactSynonym, oboInOwl:hasBroadSynonym, oboInOwl:hasNarrowSynonym,
              oboInOwl:hasRelatedSynonym))

              minus {?c owl:deprecated true}
              }
           """, initNs={"rdf": 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
                        "rdfs": 'http://www.w3.org/2000/01/rdf-schema#',
                        "owl": 'http://www.w3.org/2002/07/owl#',
                        "oboInOwl": 'http://www.geneontology.org/formats/oboInOwl#'})

    # create progress bar
    widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
    pbar = ProgressBar(widgets=widgets, maxval=len(results))

    print("Processing Query Results \n")

    for row in pbar(results):
        key = str(row[0].encode("ascii", errors="replace")).lower()

        if key in syn.keys():
            if str(row[1]) not in syn[key] and str(row[2].encode("ascii", errors="replace").lower()) not in syn[key]:
                syn[key] += [str(row[1]), str(row[2].encode("ascii", errors="replace").lower())]
        else:
            syn[key] = [str(row[1]), str(row[2].encode("ascii", errors="replace").lower())]

    # close progress bar
    pbar.finish()

    # verify we have results
    if not len(syn) > 1:
        raise ValueError('Error - did not return any DbXRefs for graph: {0}'.format(len(syn)))
    else:
        return syn


def mapper(map_terms, dic, dict_syn, dict_db):

    # map_terms= pd.read_excel('resources/data/mappings/SNOMED_CONDS_unmapped.xlsx')
    widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
    pbar = ProgressBar(widgets=widgets, maxval=len(map_terms))
    matches = []

    for names, values in pbar(map_terms.iterrows()):
        omop = values['OMOP']
        sme = values['SNOMED']
        sn = str(values['SNOMED_LABEL'].encode("utf-8")).lower().rstrip()
        ac_map = values['ANCESTOR']
        al = re.sub(r"^\s+|\s+$", "", str(values['ANCESTOR_LABEL'].encode("utf-8")).lower())
        cui = values['CUI']
        ac_cui = values['ANCESTOR_CUI']

        ont0 = []; ont_id0 = []; map0 = []; ont1 = []; ont_id1 = []; map1 = []; ont2 = []; ont_id2 = []; map2 = [];
        ont3 = []; ont_id3 = []; map3 = []; ont4 = []; ont_id4 = []; map4 = []; ont5 = []; ont_id5 = []; map5 = [];
        ont6 = []; ont_id6 = []; map6 = []; ont7 = []; ont_id7 = []; map7 = []

        # for ac in str(ac_map).split("|"):
        if ("SNOMED:" + str(sme) in dict_db.keys()) or\
           (sn in dict_syn.keys()) or (sn in dic.keys()) or \
           (cui in dict_db.keys()) or \
           (len([x for x in ac_cui.split("|") if str(x) in dict_db.keys()])>0) or \
           (len([str(x) for x in str(ac_map).split("|") if "SNOMED:" + str(x) in dict_db.keys()])>0) or \
           (len([str(x) for x in str(al).split(" | ") if str(x) in dic.keys()])>0) or \
           (len([str(x) for x in str(al).split(" | ") if str(x) in dict_syn.keys()])>0):

            if "SNOMED:" + str(sme) in dict_db.keys():
                ont1 += [" | ".join([x for x in dict_db["SNOMED:" + str(sme)] if 'http' in x])]
                ont_id1 += [" | ".join([x for x in dict_db["SNOMED:" + str(sme)] if 'http' not in x])]
                map1 += ["SNOMED_DbXRef"]
            if cui in dict_db.keys():
                ont0 += [" | ".join([x for x in dict_db[cui] if 'http' in x])]
                ont_id0 += [" | ".join([x for x in dict_db[cui] if 'http' not in x])]
                map0 += ["UMLS_DbXRef"]
            if sn in dict_syn.keys():
                ont2 += [" | ".join([x for x in dict_syn[sn] if 'http' in x])]
                ont_id2 += [" | ".join([x for x in dict_syn[sn] if 'http' not in x])]
                map2 += ["Synonym"]
            if sn in dic.keys():
                ont3 += [dic[sn][0]]
                ont_id3 += [sn]
                map3 += ["Label"]

            if len(filter(None, [x if "SNOMED:" + str(x) in dict_db.keys() else "" for x in str(ac_map).split("|")]))>0:
                res = [x for y in [dict_db.get("SNOMED:" + str(x)) for x in str(ac_map).split("|") if "SNOMED:"+str(
                    x) in  dict_db.keys()] for x in y]
                ont4 += [" | ".join([x for x in res if 'http' in x])]
                ont_id4 += [" | ".join([x for x in res if 'http' not in x])]
                map4 += ["SNOMED_DbXRef - Ancestor"]
            if len(filter(None, [x if str(x) in dict_db.keys() else "" for x in ac_cui.split(" | ")]))>0:
                res = [x for y in [dict_db.get(str(x)) for x in ac_cui.split(" | ") if str(x) in dict_db.keys()] for x in y]
                ont7 += [" | ".join([x for x in res if 'http' in x])]
                ont_id7 += [" | ".join([x for x in res if 'http' not in x])]
                map7 += ["UMLS_DbXRef - Ancestor"]
            if len(filter(None, [x if str(x) in dict_syn.keys() else "" for x in al.split(" | ")]))>0:
                res = [x for y in [dict_syn.get(str(x)) for x in al.split(" | ") if str(x) in dict_syn.keys()] for x in y]
                ont5 += [" | ".join([x for x in res if 'http' in x])]
                ont_id5 += [" | ".join([x for x in res if 'http' not in x])]
                map5 += ["Synonym - Ancestor"]
            if len(filter(None, [x if x in dic.keys() else [] for x in al.split(" | ")]))>0:
                res = [x for y in [dic.get(x) for x in al.split(" | ") if str(x) in dic.keys()] for x in y]
                ont6 += [" | ".join([x for x in res if 'http' in x])]
                ont_id6 += [" | ".join([x for x in al.split(" | ") if str(x) in dic.keys()])]
                map6 += ["Label - Ancestor"]

        # condense and group matches
        ids1 = [[x.split(" | ") if len(ont1)>0 else "" for x in ont1]] +\
               [[x.split(" | ") if len(ont0)>0 else "" for x in ont0]] +\
               [[x.split(" | ") if len(ont3)>0 else "" for x in ont3]] +\
               [[x.split(" | ") if len(ont2)>0 else "" for x in ont2]]
        nts1 = [[x.lower().split(" | ") if len(ont_id1)>0 else "" for x in ont_id1]] + \
               [[x.lower().split(" | ") if len(ont_id0)>0 else "" for x in ont_id0]] + \
               [[x.lower().split(" | ") if len(ont_id3)>0 else "" for x in ont_id3]] +\
               [[x.lower().split(" | ") if len(ont_id2)>0 else "" for x in ont_id2]]
        mps1 = [x.strip() + "(" + str(len(ids1[0][0])) + ")" if len(ids1)>=1 else "" for x in map1]+ \
               [x.strip() + "(" + str(len(ids1[1][0])) + ")" if len(ids1)>1 else "" for x in map0]+ \
               [x.strip() + "(" + str(len(ids1[2][0])) + ")" if len(ids1)>2 else "" for x in map3] +\
               [x.strip() + "(" + str(len(ids1[3][0])) + ")" if len(ids1)>3 else "" for x in map2]
        ids2 = [[x.split(" | ") if len(ont4) > 0 else ont4 for x in ont4]] + \
               [[x.split(" | ") if len(ont7) > 0 else ont7 for x in ont7]] + \
               [[x.split(" | ") if len(ont6) > 0 else ont6 for x in ont6]] + \
               [[x.split(" | ") if len(ont5) > 0 else ont5 for x in ont5]]
        nts2 = [[x.lower().split(" | ") if len(ont_id4) > 0 else "" for x in ont_id4]] + \
               [[x.lower().split(" | ") if len(ont_id7) > 0 else "" for x in ont_id7]] + \
               [[x.lower().split(" | ") if len(ont_id6) > 0 else "" for x in ont_id6]] + \
               [[x.lower().split(" | ") if len(ont_id5) > 0 else "" for x in ont_id5]]
        mps2 = [x.strip() + "(" + str(len(ids2[0][0])) + ")" if len(ont4) > 0 else "" for x in map4] + \
               [x.strip() + "(" + str(len(ids2[1][0])) + ")" if len(ont7) > 0 else "" for x in map7] + \
               [x.strip() + "(" + str(len(ids2[2][0])) + ")" if len(ont6) > 0 else "" for x in map6] + \
               [x.strip() + "(" + str(len(ids2[3][0])) + ")" if len(ont5) > 0 else "" for x in map5]

        sn_id = " | ".join(set(filter(None, [x.split("/")[-1] for y in [x for y in ids1 for x in y] for x in y])))
        sn_nt = " | ".join(set(filter(None, [x for y in [x for y in nts1 for x in y] for x in y])))
        sn_mp = " | ".join(set(filter(None, mps1)))
        an_id = " | ".join(set(filter(None, [x.split("/")[-1] for y in [x for y in ids2 for x in y] for x in y])))
        an_nt = " | ".join(set(filter(None, [x for y in [x for y in nts2 for x in y] for x in y])))
        an_mp = " | ".join(set(filter(None, mps2)))

        matches.append([omop, sme, sn, ac_map, ac_cui, al, sn_id, sn_nt, sn_mp, an_id, an_nt, an_mp])

    pbar.finish()

    # output results
    mapped = pd.DataFrame(dict(OMOP_ID=[x[0] for x in matches],
                               ANCESTOR=[x[3] for x in matches],
                               SNOMED=[x[1] for x in matches],
                               SNOMED_LABEL=[x[2] for x in matches],
                               ANCESTOR_LABEL=[x[5] for x in matches],
                               ANCESTOR_CUI =[x[4] for x in matches],
                               ONT_XREF_ID=[x[6] for x in matches],
                               ONT_XREF=[x[7] for x in matches],
                               ONT_XREF_MAP=[x[8] for x in matches],
                               ONT_SYN_ID=[x[9] for x in matches],
                               ONT_SYN=[x[10] for x in matches],
                               ONT_SYN_MAP=[x[11] for x in matches]))

    mapped_terms = mapped[['OMOP_ID', 'SNOMED', 'SNOMED_LABEL', 'ANCESTOR', 'ANCESTOR_LABEL', 'ANCESTOR_CUI', 'ONT_XREF_ID',
                           'ONT_XREF', 'ONT_XREF_MAP', 'ONT_SYN_ID', 'ONT_SYN', 'ONT_SYN_MAP']]

    mapped_terms = mapped_terms.drop_duplicates(['OMOP_ID', 'SNOMED', 'SNOMED_LABEL', 'ANCESTOR', 'ANCESTOR_LABEL',
                                                 'ANCESTOR_CUI', 'ONT_XREF_ID', 'ONT_XREF', 'ONT_XREF_MAP',
                                                 'ONT_SYN_ID', 'ONT_SYN', 'ONT_SYN_MAP'], keep="first")

    return mapped_terms


def SNO_CUI(map_terms, df):
    """
    function takes a pandas data frame of terms to map and a data frame of CUI to SNOMED mapping information (
    MRCONSO). Things that are not in the files are then searched using the UMLS API
    :param map_terms:
    :param df:
    :return:
    """

    mapped = []
    for row, val in map_terms.iterrows():
        print row
        omop = val['OMOP']
        sn = val['SNOMED']
        anc_map = str(val['ANCESTOR'])
        anc_cui = []

        for i in anc_map.split("|"):
            # ser = df.loc[df[13] == str(i)][0]
            #
            # if len(ser) != 0:
            #     ac_cui = [list(set(list(ser)))[0] if len(ser) != 0 else ""][0]
            #     anc_cui.append(ac_cui)
            # else:
                cui = CodeSearch("https://uts-ws.nlm.nih.gov", i, "current")
                anc_cui.append(str(cui[0]['ui']) if cui else "")

        mapped.append([omop, sn, anc_map, " | ".join(anc_cui)])

    mapped_cui = pd.DataFrame(dict(OMOP=[x[0] for x in mapped],
                                   SNOMED=[x[1] for x in mapped],
                                   ANCESTOR=[x[2] for x in mapped],
                                   ANCESTOR_CUI=[x[3] for x in mapped]))

    map_cui = mapped_cui.drop_duplicates(keep="first")

    return map_cui


def UMLS_MAPPER(maps, search_type):
    """
    Function takes a data frame and tries to map SNOMED IDs to UMLS CUIs and semantic types. Function can search for CUIs by code orr label
    :param maps:
    :param search_type:
    :return:
    """

    widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
    pbar = ProgressBar(widgets=widgets, maxval=len(maps))
    typ = []

    maps = map_terms.loc[map_terms['CUI'] == ""]

    for key, val in pbar(maps.iterrows()):
        print key
        sn = val['SNOMED']
        sme = val['SNOMED_LABEL']

        if search_type == "term":
            TermSearch("https://uts-ws.nlm.nih.gov",
                       sme,
                       "current")

            res2 = TermSearch("https://uts-ws.nlm.nih.gov", sme, "current")
        else:
            res2=CodeSearch("https://uts-ws.nlm.nih.gov", sn, "current")

        cui = [res2[0]['ui'] if len(res2)>0 else ""][0]

        # search semantic type for mapped SNOMED ids
        if cui != "":
            res = CUISearch("https://uts-ws.nlm.nih.gov", cui,version='current')
            tui = '|'.join([str(x['name']) for x in res['semanticTypes']])
            typ.append([val['OMOP'], sn, cui, tui])
        else:
            print val['SNOMED']

    ont_inf = pd.DataFrame(dict(OMOP=[x[0] for x in typ],
                               SNOMED=[x[1] for x in typ],
                               CUI=[x[2] for x in typ],
                               TUI=[x[3] for x in typ]))

    ont_inf = ont_inf.drop_duplicates(keep = "first")

    return ont_inf

#
def main():


# if __name__ == '__main__':
#     main()

#########################################################################
#########################################################################

## Mapping first to CUIs
# read in clinical concepts to map
map_terms = pd.read_excel('resources/data/mappings/SNOMED_CONDS_11.16.2018.xlsx', sheet_name = "Main Mapping")
map_terms = map_terms.fillna('')
df = pd.read_csv('resources/data/mappings/MRCONSO.RRF', sep="|",header=None)
df = df.loc[(df[11] == 'SNOMEDCT_US') & (df[1]=="ENG")]
df = df[[0,11,13,14]]

map_cui = SNO_CUI(map_terms, df)
map_cui.to_csv('resources/data/mappings/ANCESTOR_CUIS.csv', sep=str(','), index=False)

# get UMLS CUI and semantic type using the UMLS API
ont_inf= UMLS_MAPPER(map_terms)
ont_inf.to_csv('resources/data/mappings/MAPPED_CUIS.csv', sep=str(','), index=False)


## DbXRef mapping using the ontology information
graph_do = Graph()
graph_do.parse("http://purl.obolibrary.org/obo/doid.owl", format="xml")



graph_hp = Graph()
graph_hp.parse("http://purl.obolibrary.org/obo/hp.owl", format="xml")

graph = Graph()
graph.parse("http://purl.obolibrary.org/obo/chebi.owl", format="xml")

# run query to get all dbXref
## DOID
do = OntDict(graph_do) #9095
do_db = DbXRef(graph_do) #3694
do_syn = Synonym(graph_do) #14584
## HP
hp = OntDict(graph_hp) #13725
hp_db = DbXRef(graph_hp) #4423
hp_syn = Synonym(graph_hp) #17470

# read in clinical concepts to map
map_terms = pd.read_excel('resources/data/mappings/SNOMED_CONDS_11.16.2018.xlsx', sheet_name = "Main Mapping")
map_terms = map_terms.fillna('')

hp_mapped_terms = mapper(map_terms, hp, hp_syn, hp_db)
hp_mapped_terms.to_csv('resources/data/mappings/CONDS_DBXREF_HP_SYN.csv', sep=str(','), index=False)
do_mapped_terms = mapper(map_terms, do, do_syn, do_db)
do_mapped_terms.to_csv('resources/data/mappings/CONDS_DBXREF_DO_SYN.csv', sep=str(','), index=False)


# ## WIKIPEDIA MAPPING
# # https://pymediawiki.readthedocs.io/en/latest/code.html#mediawiki.MediaWiki
# from mediawiki import MediaWiki
# from mediawiki import exceptions
# import datetime
# wikipedia = MediaWiki(rate_limit=True,
#                       rate_limit_wait=datetime.timedelta(0, 0, 50000),
#                       user_agent='pyMediaWiki-call')
# mapped = []
# for row, val in map_terms[27630:].iterrows():
#     print str(row) + "\n"
#     sme = " ".join([str(WordNetLemmatizer().lemmatize(x)) for x \
#                                          in RegexpTokenizer(r"\w+").tokenize(val['SNOMED_LABEL'].encode("ascii",
#                                          errors="replace").lower()) if x not in stopwords.words("english") +\
#                                          ["right", "left", "lateral", "bilateral"]])
#
#     # search for any wikipedia pages on concept
#     match = wikipedia.search("Atrophic pharyngitis", results=1)
#     wikipedia.page(match[0]).summarize().encode("ascii", errors="replace")
#
#     if len(match)>0:
#         try:
#             res_sme = wikipedia.page(match[0]).summarize().encode("ascii", errors="replace")
#             print sme, match
#             print "\n"
#         except exceptions.DisambiguationError:
#             search = [s if "med" in s else str(sme) + " medical concept" for s in wikipedia.search(sme, results=50)]
#             try:
#                 res_sme = wikipedia.page(wikipedia.search(search[0], results=1)[0]).summarize().encode("ascii",errors="replace")
#                 print sme, search[0]
#                 print "\n"
#             except exceptions.DisambiguationError:
#                 print "no match"
#
#         except exceptions.PageError:
#             # use ancestor concepts to help improve search
#             term_update = str(sme) + " " + str(val['ANCESTOR_LABEL'].encode("ascii", errors="replace").lower())
#             search = wikipedia.search(term_update, results=1)[0]
#             try:
#                 res_sme = wikipedia.page(search).summarize().encode("ascii",errors="replace")
#                 print sme, search
#
#                 print "\n"
#             except exceptions.PageError:
#                 print "no match"
#
#         mapped.append([val['OMOP'], val['SNOMED'], val['SNOMED_LABEL'],
#                        val['ANCESTOR'], val['ANCESTOR_LABEL'], res_sme])
#
# ont_inf = pd.DataFrame(dict(OMOP=[x[0] for x in mapped],
#                            SNOMED=[x[1] for x in mapped],
#                            SNOMED_LABEL=[x[2] for x in mapped],
#                             ANCESTOR=[x[3] for x in mapped],
#                             ANCESTOR_LABEL=[x[4] for x in mapped],
#                             WIKI_DEF=[x[5] for x in mapped]))
#
# ont_inf = ont_inf.drop_duplicates(keep = "first")
# ont_inf.to_csv('resources/data/mappings/MAPPED_WIKI.csv', sep=str(','), index=False)







# export current DOID and HP ontology id and label list
# ont =[]
#
# widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
# pbar = ProgressBar(widgets=widgets, maxval=len(do))
# for key, val in pbar(do.items()):
#     label = key; defn = val[1]; id = val[0]; syn = []
#     for k,v in do_syn.items():
#         for i in v[0::2]:
#             if str(i) == str(id):
#                 syn.append(k)
#
#     ont.append([id, label, defn, " | ".join(syn)])
# pbar.finish()
#
# widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
# pbar = ProgressBar(widgets=widgets, maxval=len(hp))
# for key, val in pbar(hp.items()):
#     label = key; defn = val[1]; id = val[0]; syn = []
#     for k,v in hp_syn.items():
#         for i in v[0::2]:
#             if str(i) == str(id):
#                 syn.append(k)
#
#     ont.append([id, label, defn, " | ".join(syn)])
# pbar.finish()
#
# ont_inf = pd.DataFrame(dict(ONT=[x[0] for x in ont],
#                            LABEL=[x[1] for x in ont],
#                            DEF=[x[2] for x in ont],
#                            SYN=[x[3] for x in ont]))
#
# ont_inf = ont_inf.drop_duplicates(keep = "first")
# len(ont_inf)
# ont_inf.to_csv('resources/data/mappings/HP_DOID_FULL.csv', sep=str(','), index=False)





### ATTEMPT 2 - bag of similarity-based approach
## PRE-PROCESS DATA & BUILD CORPORA
# var_col and defn_col hold information from the data frame and are used when processing the data
# datavar_col = ["OMOP", "SNOMED"]
# defn_col = "SNOMED_LABEL"
# label = ["SNOMED_LABEL"]
var_col = ["OMOP", "ANCESTOR"]
defn_col = "ANCESTOR_LABEL"
label = ["ANCESTOR_LABEL"]

corpus = preprocessor(map_terms, var_col, defn_col, hp_syn, hp)
corpus = preprocessor(map_terms, var_col, defn_col, do_syn, do)

## BUILD TF-IDF VECTORIZER
tf = TfidfVectorizer(tokenizer=lambda x: x, preprocessor=lambda x: x, use_idf=True, norm="l2", lowercase=False)

## CREATE MATRIX AND VECTORIZE DATA
tfidf_matrix = tf.fit_transform([content for var, content in corpus])
tfidf_matrix.shape

## SCORE DATA + WRITE OUT RESULTS
scored = score_variables(var_col, defn_col, label, map_terms, corpus, tfidf_matrix, len(map_terms)-1)

# write data
# order columns
# scored.to_csv('resources/data/mappings/CONDS_SNO_HP.csv', sep=str(','), encoding = 'utf-8', index=False)
# scored.to_csv('resources/data/mappings/CONDS_ANC_HP.csv', sep=str(','), encoding = 'utf-8', index=False)
# scored.to_csv('resources/data/mappings/CONDS_SNO_DO.csv', sep=str(','), encoding = 'utf-8', index=False)
scored.to_csv('resources/data/mappings/CONDS_ANC_DO.csv', sep=str(','), encoding = 'utf-8', index=False)



#########################################################################
#########################################################################

chebi= pd.read_excel('resources/data/mappings/CHEBI.xlsx', encoding='utf-8-sig', sheet=)
chebi.Synonyms = chebi.Synonyms.fillna('')
chebi['Preferred Label'] = chebi['Preferred Label'].fillna('')

graph_dict2 = {}
for names, values in chebi.iterrows():

    if values['Preferred Label'] != "":
        key1 = str(values['Preferred Label'].encode("ascii", errors="replace")).lower()
        graph_dict2[key1] = [str(values['Class ID'])]

        if values['Synonyms'] != "":
            for j in [str(x).lower() for x in str(values['Synonyms'].encode("ascii", errors="replace")).split("|")]:
                graph_dict2[j] = [str(values['Class ID'])]


map_terms = pd.read_excel('resources/data/mappings/RXNORM_MEDS_to_map2.xlsx')
widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
pbar = ProgressBar(widgets=widgets, maxval=len(map_terms))

al_matches_doid = []
for names, values in pbar(map_terms.iterrows()):
    omop = values['OMOP_ID']
    sme = values['RXNORM_ID']
    ac_id = values['Ancestor_ID']
    sn = str(values['RXNORM_Label']).lower().rstrip()
    al = str(values['Ancestor_Label']).lower().rstrip()

    if " / " in sn:
        for i in sn.split(" / "):
            match = re.sub(r'(^.*\d)\s([a-z]{,4})\s', "", re.sub(r'\s\W.+|\s\d.+', "", i).rstrip()).rstrip()

            if "vaccine" in sn:
                al_matches_doid.append([omop, sme, sn, ac_id, al, "NONE", "VACCINE"])
            elif "antigen" in sn:
                al_matches_doid.append([omop, sme, sn, ac_id, al,"NONE", "IMMUNIZATION"])
            elif i in graph_dict2.keys():
                al_matches_doid.append([omop, sme, sn, ac_id, al, i, graph_dict2[i][0]])
            elif match in graph_dict2.keys():
                al_matches_doid.append([omop, sme, sn, ac_id, al, match, graph_dict2[match][0]])
            else:
                al_matches_doid.append([omop, sme, sn, ac_id, al, match, ""])
    else:
        match = re.sub(r'(^.*\d)\s([a-z]{,4})\s', "", re.sub(r'\s\W.+|\s\d.+', "", sn).rstrip()).rstrip()

        if "vaccine" in sn:
            al_matches_doid.append([omop, sme, sn, ac_id, al, "VACCINE"])
        elif "antigen" in sn:
            al_matches_doid.append([omop, sme, sn, ac_id, al, "IMMUNIZATION"])
        elif sn in graph_dict2.keys():
            al_matches_doid.append([omop, sme, sn, ac_id, al, sn, graph_dict2[sn][0]])
        elif match in graph_dict2.keys():
            al_matches_doid.append([omop, sme, sn, ac_id, al, match, graph_dict2[match][0]])
        else:
            al_matches_doid.append([omop, sme, sn, ac_id, al, match, ""])

mapped_al_hp = pd.DataFrame(dict(OMOP_ID=[x[0] for x in al_matches_doid],
                           RXNORM_ID=[x[1] for x in al_matches_doid],
                           RXNORM_LABEL=[x[2] for x in al_matches_doid],
                           ANCESTOR_ID=[x[3] for x in al_matches_doid],
                           ANCESTOR_LABEL=[x[4] for x in al_matches_doid],
                           Match=[x[5] for x in al_matches_doid],
                           Match_ID=[x[6] for x in al_matches_doid]))

al_map_terms = mapped_al_hp.drop_duplicates(keep=False)  # 20283

# 'resources/data/mappings/SNOMED_CONDS_mapped_09.04.18.csv'
al_map_terms.to_csv('resources/data/mappings/ontology_synonyms_chebi2.csv', sep=',', encoding='utf-8', index=False)





#########################################################################
#########################################################################


    # # set-up arguments for arg parse
    # parser = argparse.ArgumentParser(description='Clinical Terminology Mapper: This program maps clinical terminology '
    #                                              'Concepts to ontology concepts.')
    # parser.add_argument('-c', '--choice', help="Map using NCBO API (A) or Ontology DbXref (B)")
    # parser.add_argument('-f', '--file', help="filepath/name.csv of clinical concepts to be mapped")
    # parser.add_argument('-a', '--auth', help="filepath/name.txt to file containing API key")
    # parser.add_argument("-o", "--output", help="filepath/name.csv for writing mapping results", required=True)
    # args = parser.parse_args()


#     ## NCBO API
#     if args.choice == "A":
#         print("Beginning clinical terminology mapping using the NCBO API" + "\n")
#
#         # set rest API URL
#         REST_URL = "http://data.bioontology.org"
#
#         ## AUTHENTICATION
#         print("Authenticating API key")
#         # authenticate and verify connection
#         # "authentication"
#         API_KEY = authenticate("authentication")[0]
#
#         ## READ IN DATA
#         print("Reading in Clinical Concepts")
#         # read in list of search terms
#         # term_file = 'resources/data/mappings/RxNORM_MEDS_08.30.18.xlsx'
#         terms_file = pd.read_excel(str(args.file))
#
#         # search for every term
#         # search_query = "/search?ontologies=CHEBI&q="
#         query = str(raw_input("Please specify the ontology or ontologies you wish to map to. If more than one, "
#                              "please separate each ontology with a comma (e.g. CHEBI, GO): "))
#         search_query = "/search?ontologies=" + str(query) + "&q="
#
#         ## QUERY API
#         print("Querying API")
#
#         primary = str(raw_input("Please enter the name of the primary mapping column (should match a column name in "
#                                 "the input terms file): "))
#         secondary = str(raw_input("Please enter the name of the secondary mapping column (should match a column name "
#                                   "in the input terms file): "))
# #
# #         # loop over clinical concepts and query the API
# #         search_results = {}
# #         widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
# #         pbar = ProgressBar(widgets=widgets, maxval=len(terms_file))
# #
# #         # for term in terms
# #         for index, row in pbar(terms_file.iterrows()):
# #             term = str(row[str(primary)].lower())
# #
# #             if term not in search_results.keys():
#
#         search_query = "/search?ontologies=SNOMEDCT&q="
#         val1 = result_searcher(REST_URL, search_query, "Palpable undescended testicle", API_KEY)
# #
#                 # checking ingredients
#                 if val1[0] != 'NONE' and val1[0] != "":
#                     search_results[term] = val1
#                 else:
#                     # checking pharmacologic class
#                     if str(row[str(secondary)]) != 'nan':
#                         val2 = result_searcher(REST_URL, search_query, str(row[str(secondary)].lower()), API_KEY)
#                         if val2[0] != "NONE":
#                             search_results[term] = val2
#                         else:
#                             search_results[term] = ["NONE", "NONE"]
#                     else:
#                         search_results[term] = ["NONE", "NONE"]
#
#         # close progress bar
#         pbar.finish()
#
#         ## OUTPUT RESULTS
#         print("Writing results to computer")
#
#         # loop over results and create an ordered list
#         map_id = []
#         map_ont = []
#         map_ont_label = []
#
#         for name, values in terms_file[str(primary)].iteritems():
#             map_id.append(name)
#             map_ont.append(search_results[str(values.lower())][0])
#             map_ont_label.append(search_results[str(values.lower())][1])
#
#         # combine results with original data
#         mapped = pd.DataFrame(dict(Index=map_id, Ont_ID=[x for x in map_ont], Ont_Label=[x for x in map_ont_label]))
#         mapped.set_index('Index', inplace=True)
#         map_terms = pd.merge(terms_file, mapped, left_index=True, right_index=True)
#
#         # write file to drive
#         # 'resources/data/mappings/RxNORM_MEDS_mapped_09.04.18.csv'
#         map_terms.to_csv(args.output, sep=',', encoding='utf-8', index=False)
#
#
#     ## ONTOLOGY FILE - DbXRef
#     if args.choice == "B":
#         print("Beginning clinical terminology mapping using an ontology's DbXrefs" + "\n")
#
#         # gather extra data from user for use with mapping to API after DbXrefs
#         # 'SNOMED_ancestor_Label'
#         first = str(raw_input("Please enter the name of the first mapping column (should match a column name in "
#                                 "the input terms file): "))
#         second = str(raw_input("Please enter the name of the second mapping column (should match a column name "
#                                   "in the input terms file): "))
#         third = str(raw_input("Please enter the name of the third mapping column (should match a column name "
#                                   "in the input terms file): "))
#         query = str(raw_input("Please specify the ontology or ontologies you wish to map to. If more than one, "
#                               "please separate each ontology with a comma (e.g. CHEBI,GO): "))
#
#         # set rest API URL
#         REST_URL = "http://data.bioontology.org"
#
#         ## AUTHENTICATION
#         print("Authenticating API key")
#         # authenticate and verify connection
#         # "authentication"
#         # API_KEY = authenticate(args.auth)[0]
#         API_KEY = authenticate("authentication")[0]
#
#         ## READ IN DATA
#         # read in list of search terms
#         # c
#         # terms_file = pd.read_excel(args.file)
#         terms_file = pd.read_excel('resources/data/mappings/SNOMED_CONDS_11.16.2018.xlsx', sheet_name="Main Mapping")
#
#         ## DOWNLOADING ONTOLOGIES
#         print("Downloading Ontology")
#
#         # ask user for ontology url
#         num = int(raw_input("Enter the number of ontologies you wish to map to: "))
#         graph = Graph()
#
#         # http://purl.obolibrary.org/obo/doid.owl
#         if num == 1:
#             url = str(raw_input("Please specify the url for the ontology you wish to map to: "))
#
#             # download ontology and create graphs
#             print("Downloading: " + str(url))
#             graph.parse(url, format="xml")
#
#         if num > 1:
#             for i in range(num):
#                 url = str(raw_input("Please specify the url for the ontology you wish to map to: "))
#
#                 # download ontology and create graphs
#                 print("Downloading: " + str(url))
#                 graph.parse(url, format="xml")
#
#         ## PROCESS RESULTS
#         print("Process Results")
#
#         # retrieve DbXref terms from ontology
#         mapping_ont = str(raw_input("Please enter the name of the clinical terminology you want to map: "))
#         # "SNOMED"
#         results = DbXref_finder(graph, mapping_ont)
#
#         # save results as dictionary
#         search_results = {}
#         for x in results:
#             if x[0] in search_results.keys():
#                 search_results[x[0]].append(list(x[1:]))
#             else:
#                 search_results[x[0]] = [list(x[1:])]
#
#         # loop over terms and process results
#         # rows= 63257
#         widgets = [Percentage(), Bar(), FormatLabel('(elapsed: %(elapsed)s)')]
#         # pbar = ProgressBar(widgets=widgets, maxval=len(terms_file[rows:]))
#         pbar = ProgressBar(widgets=widgets, maxval=len(terms_file))
#
#         # loop over results and create an ordered list
#         omop_id = []; map_id = []; map_ont = []; map_ont_label = []
#
#         for name, values in pbar(terms_file[4357:].iterrows()):
#             if values['UnMapped: 12631'] != 1:
#                 print "\n"
#                 res = terms_file[str(first)][name].encode("ascii", errors="replace").lower() + " | "\
#                       + terms_file[str(second)][name].encode("ascii", errors="replace").lower()
#                 for term1 in res.split(" | "):
#                     print term1
#                     # query = values['SNOMED_LABEL']
#                     search_query = "/search?ontologies=" + str(query) + "&q="
#                     # term1 = re.sub("[-|%|!|]", "", str(terms_file[str(first)][name]).lower())
#                     val1 = result_searcher(REST_URL, search_query, term1, API_KEY)
#                     # term2 = re.sub("[-|%|!|]", "", str(terms_file[str(second)][name]).lower())
#                     # val2 = result_searcher(REST_URL, search_query, term2, API_KEY)
#                     # term3 = re.sub("[-|%|!|]", "", str(terms_file[str(third)][name]).lower())
#                     # val3 = result_searcher(REST_URL, search_query, term3, API_KEY)
#                     print val1
#
#                     if 'NONE' not in val1:
#                         for res in [val1]:
#                             omop_id.append(terms_file["OMOP"][name])
#                             map_id.append(terms_file["SNOMED"][name])
#                             map_ont.append(res[0])
#                             map_ont_label.append(res[1].lower())
#
#         # close progress bar
#         pbar.finish()
#
#         ## OUTPUT RESULTS
#         print("Writing results to computer")
#
#         # combine results with original data
#         mapped = pd.DataFrame(dict(OMOP_ID=omop_id,
#                                    SNOMED_ID=map_id,
#                                    Ont_ID=[x for x in map_ont],
#                                    Ont_Label=[x for x in map_ont_label]))
#
#         map_terms = pd.merge(terms_file, mapped, on=['OMOP_ID', 'SNOMED_ID'])
#         map_terms = map_terms.drop_duplicates(keep=False)  # 45054
#
#         # write file to drive
#         # 'resources/data/mappings/SNOMED_CONDS_mapped_09.04.18.csv'
#         mapped.to_csv('resources/data/mappings/MAPPED.csv', sep=',', encoding='utf-8', index=False)
#
#         map_terms.to_csv(args.output, sep=',', encoding='utf-8', index=False)


## fizzBuzz

for i in xrange(1,25):
    if i%3 == 0 and i%5 == 0:
        print "FizzBuzz"
    elif i%3 == 0:
        print "Fizz"
    elif i%5 == 0:
        print "Buzz"
    else:
        print i


# Function for nth Fibonacci number

def FibSeqIter(n):

    count = 0
    x, y = 0, 1

    while count < n:
        print(x)
        x, y = y, x + y
        count += 1

    return None

FibSeqIter(10)


def FibSeqRec(n):

    if n <= 1:
        return n
    else:
        return FibSeqRec(n - 1) + FibSeqRec(n - 2)

for i in range(10):
    print FibSeqRec(i)


def PowerFinder(power_num, n):

    ans = int(math.log10(n)/math.log10(power_num))

    if power_num**ans == n:
        return "Yes, " + str(n) + " is a power of " + str(power_num)
    else:
        return "No, " + str(n) + " is not a power of " + str(power_num)

PowerFinder(2, 4)
PowerFinder(3, 9)


def numType(n):

    # if n%2 == 0:
    if int(n/2)*2 == n:
        return str(n) + " is an even number"
    else:
        return str(n) + " is an odd number"

numType(0)
numType(2)
numType(9)


def isPrime(n):
    # Corner case
    if n <= 1:
        return False

    # Check from 2 to n-1
    for i in range(2, n):
        if n % i == 0:
            return False

    return True

isPrime(4)
isPrime(1)
isPrime(2)


def anagram(a,b):
    if type(a) or type(b) != str or len(a) != len(b):
        return False
    elif sorted(list(a)) == sorted(list(b)):
        return True
    else:
        return False

anagram("earth", "heart")
anagram("earth", "heart3")
anagram("earth", "rate")
anagram("earth", "earth    ")
anagram(1,"red")
anagram(1,2)