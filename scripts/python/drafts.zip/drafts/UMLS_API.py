#############################################################################
# UMLS_API.py
# Purpose: runs queries against UMLS REST API
# resource: https://github.com/HHS/uts-rest-api/tree/master/samples/python
# version 1.0.0
# date: 11.18.2018
#############################################################################


## import module/script dependencies
import requests, json
from requests.exceptions import *
import sys
from time import sleep
from scripts.Authentication import *



def TermSearch(uri, term, version ='current'):
    '''
    This function takes a string containing the UMLS REST API URI, a string containing a term, and a string specifying
    UMLS version to query (default is set to query the most up to date version). Using this information the REST API is
    queried. Function returns a list of dictionaries containing the results of the query. Additional input/output
    arguments for query can be found: https://documentation.uts.nlm.nih.gov/rest/search/index.html.
    :param uri: a string that containing the UMLS REST API URI
    :param term: a string containing a term
    :param version: a string specifying UMLS version to query (default is set to query the most up to date version)
    :return: list of dictionaries containing the results of the query
    '''

    # get session ticket
    AuthClient = Authentication()
    content_endpoint = "/rest/search/" + version
    pageNumber = 0

    # results
    UMLS_results = []

    # initialize variables
    result = ''

    while result != 'NO RESULTS':

        # generate a new service ticket for each page if needed
        ticket = AuthClient.getst(AuthClient.gettgt())
        pageNumber += 1
        query = {'string': term, 'ticket': ticket, 'pageNumber': pageNumber}
        query['searchType'] = "exact"

        # request results and track certain exceptions
        tries = 0
        r = ''
        while r == '' and tries != 20:

            try:
                r = requests.get(uri + content_endpoint, params=query)
                r.encoding = 'utf-8'

            except requests.exceptions.Timeout:
                sleep(10)
                tries += 1

            except requests.exceptions.ConnectionError as e:
                sleep(10)
                tries += 1

            except requests.exceptions.RequestException as e:
                # catastrophic error. bail.
                print e
                sys.exit(1)

        # retrieve results
        items = json.loads(r.text)
        jsonData = items["result"]

        # test if results were found
        if jsonData["results"][0]['name'] == 'NO RESULTS':
            result = jsonData["results"][0]['name']

        else:
            UMLS_results.append(jsonData["results"][0])

    out_message = 'UMLS API returned: %d' % len(UMLS_results) + ' result(s) for ' + str(term)

    print '\n'
    print '=' * len(out_message)
    print out_message
    print '=' * len(out_message)
    print '\n'

    return UMLS_results



def CodeSearch(uri, code, version = 'current'):
    '''
    This function takes a string containing the UMLS REST API URI, a string containing a source concept code, and a
    string specifying UMLS version to query (default is set to query the most up to date version). Using this
    information the REST API is queried. Function returns a list of dictionaries containing the results of the query.
    Additional input/output arguments for query can be found:
    https://documentation.uts.nlm.nih.gov/rest/search/index.html.
    :param uri: a string that containing the UMLS REST API URI
    :param code: a string containing a source concept code
    :param version: a string specifying UMLS version to query (default is set to query the most up to date version)
    :return: list of dictionaries containing the results of the  query
    '''

    # get session ticket
    AuthClient = Authentication()
    content_endpoint = "/rest/search/" + version
    pageNumber = 0

    # results
    UMLS_results = []

    # initialize variables
    result = ''

    while result != 'NO RESULTS':

        # request results and track certain exceptions
        tries = 0
        r = ''
        while r == '' and tries != 20:

            try:
                # generate a new service ticket for each page if needed
                ticket = AuthClient.getst(AuthClient.gettgt())
                pageNumber += 1
                query = {'string': code, 'ticket': ticket, 'pageNumber': pageNumber}
                query['inputType'] = 'sourceUi'
                query['searchType'] = "exact"
                query['includeObsolete'] = 'true'
                query['includeSuppressible'] = 'true'

                r = requests.get(uri + content_endpoint, params=query)
                r.encoding = 'utf-8'

            except requests.exceptions.Timeout as e:
                print 'Timeout ' + str(e)
                print '\n'

                # sleep and then try again
                sleep(10)
                tries += 1

                # generate a new service ticket for each page if needed
                ticket = AuthClient.getst(AuthClient.gettgt())
                pageNumber += 1
                query = {'string': code, 'ticket': ticket, 'pageNumber': pageNumber}
                query['inputType'] = 'sourceUi'
                query['searchType'] = "exact"
                query['includeObsolete'] = 'true'
                query['includeSuppressible'] = 'true'

            except requests.exceptions.ConnectionError as e:
                print 'ConnectionError ' + str(e)
                print '\n'

                # sleep and then try again
                sleep(10)
                tries += 1

                # generate a new service ticket for each page if needed
                ticket = AuthClient.getst(AuthClient.gettgt())
                pageNumber += 1
                query = {'string': code, 'ticket': ticket, 'pageNumber': pageNumber}
                query['inputType'] = 'sourceUi'
                query['searchType'] = "exact"
                query['includeObsolete'] = 'true'
                query['includeSuppressible'] = 'true'

            except requests.exceptions.RequestException as e:
                print e
                print '\n'

                # exit
                sys.exit(1)

        # load results
        items = json.loads(r.text)
        jsonData = items["result"]

        # test if results were found
        if jsonData["results"][0]['name'] == 'NO RESULTS':
            result = jsonData["results"][0]['name']

        else:
            UMLS_results.append(jsonData["results"][0])

    out_message = 'UMLS API returned: %d' % len(UMLS_results) + ' result(s) for ' + str(code)

    # print '\n'
    # print '=' * len(out_message)
    # print out_message
    # print '=' * len(out_message)
    # print '\n'

    return UMLS_results


def CUISearch(uri, cui, version = 'current'):
    '''
    This function takes a string containing the UMLS REST API URI, a string containing a UMLS CUI, and a string
    specifying UMLS version to query (default is set to query the most up to date version). Using this information the
    REST API is queried. Function returns a dictionary containing the results for a single query. Additional input
    and output information can be found: https://documentation.uts.nlm.nih.gov/rest/concept/index.html.
    :param uri: a string that containing the UMLS REST API URI
    :param cui: a string containing a UMLS CUI
    :param version: a string specifying UMLS version to query (default is set to query the most up to date version)
    :return: dictionary containing the results for a single query
    '''

    # get session ticket
    AuthClient = Authentication()
    tgt = AuthClient.gettgt()
    content_endpoint = "/rest/content/" + str(version) + "/CUI/" + str(cui)

    # ticket is the only parameter needed for this call
    query = {'ticket': AuthClient.getst(tgt)}

    # request results and track certain exceptions
    tries = 0
    r = ''
    while r == '' and tries != 20:

        try:
            r = requests.get(uri + content_endpoint, params=query)
            r.encoding = 'utf-8'

        except requests.exceptions.Timeout:
            sleep(10)
            tries += 1

        except requests.exceptions.ConnectionError as e:
            sleep(10)
            tries += 1

        except requests.exceptions.RequestException as e:
            # catastrophic error. bail.
            print e
            sys.exit(1)

    # retrieve results
    items = json.loads(r.text)
    jsonData = items["result"]

    out_message = 'Finished searching for CUI information'

    # print '\n'
    # print '=' * len(out_message)
    # print out_message
    # print '=' * len(out_message)
    # print '\n'

    return jsonData


# def main():
#
#     # provide API key and version information
#     apikey = " "
#     version = "current"
#     uri = "https://uts-ws.nlm.nih.gov"
#
#     ## SEARCH ##
#     # search by term
#     term = "Vitreoretinal dystrophy"
#     res = TermSearch(uri, term, version)
#
#     res = TermSearch("https://uts-ws.nlm.nih.gov", term, "current")
#     cui = CUISearch(uri, str(res[0]['ui']),  version='current')
#     tui = cui['semanticTypes'][0]['name']
#
#
#
#     # search by code
#     code = "10070907"
#     res = CodeSearch(uri, "267247006", version)
#
#     # search for CUI
#     cui = "C0206172"
#     res = CUISearch(uri, cui, version = 'current')
#
#
# if __name__ == "__main__":
#     main()
